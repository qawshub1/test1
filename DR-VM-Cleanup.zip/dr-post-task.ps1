Write-Host “Please enter the vCenter Host IP Address:”
$VMHost = Read-Host

Write-Host “Please enter the vCenter Username:”
$User = Read-Host

Write-Host “Please enter the vCenter Password:” -AsSecureString
$Pass = Read-Host 

Connect-VIServer -Server $VMHost -User $User -Password $Pass

$vms = Import-Csv c:\scripts\DR-VMs.csv -UseCulture

foreach($row in $vms){
Stop-VM -VM $($row.oldname) -Confirm:$false -RunAsync | Out-Null} 

Start-Sleep -Seconds 7

FOREACH ($row in $vms)
{ Get-VM $($row.oldname) | Set-vm -name $($row.newname) -confirm:$false
   }

Start-Sleep -Seconds 7

FOREACH ($row in $vms){
Get-VM -Name $($row.newname)| Set-VM -OSCustomizationSpec $($row.newname) -confirm:$false
}

Start-Sleep -Seconds 7

## Change the network adapter
FOREACH ($row in $vms){
Get-VM -Name $($row.newname) | Get-NetworkAdapter  | Set-NetworkAdapter  -NetworkName "dvPG-EM-APP-Tier-vlan1005" -Confirm:$false
}

Start-Sleep -Seconds 7

FOREACH ($row in $vms){
Start-VM -VM $($row.newname) -Confirm:$false -RunAsync | Out-Null} 
