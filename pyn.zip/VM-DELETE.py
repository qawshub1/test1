#!/usr/bin/env python3
###Author Selvakumar Arumugam
#######################################
import pysed
import os
import sys
import fileinput
from getpass import getpass
from sh import sed
from openpyxl import load_workbook
from ansible import playbook
from pyutil import filereplace
#os.environ['VMWARE_USER'] = str(VMWARE_USER)
#os.environ['VMWARE_PASSWORD'] = str(VMWARE_PASSWORD)
x = os.path.abspath("/etc/ansible/power-off-servers.txt")
#file1 = open(x, 'a')
file2 = open(x, 'r')

os.system('cat /opt/VM-DECOMM-AUTO/export-template.sh > /opt/VM-DECOMM-AUTO/export.sh')
os.system(' cat /dev/null > /opt/VM-DECOMM-AUTO/cvlt-delete-client.txt')
os.system(' cat /dev/null > /opt/VM-DECOMM-AUTO/BigFix-delete-client.txt')
os.system(' cat /dev/null > /var/log/vm_delete_result.log')
os.system('/bin/chattr +i /apps/sre-share/vm-delete.xlsx')

wb = load_workbook(filename='/apps/sre-share/vm-delete.xlsx', read_only=True)
ws = wb.active
row_count = ws.max_row
column_count = ws.max_column
row_count += 1
A="A"
DOMAIN=".corp.equinix.com"
#########################################################################
#### Add data to "/opt/VM-DECOMM-AUTO/BigFix-delete-client.txt"
#########################################################################
for row in  range(2,row_count):
    y = os.path.abspath("/opt/VM-DECOMM-AUTO/BigFix-delete-client.txt")
    file1 = open(y, 'a')
    file1.write("\n")
    file1.write((ws['A'+str(row)].value))
    file1.write("\n")
    file1.write((ws['A'+str(row)].value)+ DOMAIN)
    file1.close()

os.system(' /bin/bash /opt/VM-DECOMM-AUTO/export-user-delete.sh')

#########################################################################
#### Add data to "/opt/VM-DECOMM-AUTO/cvlt-delete-client.txt"
#########################################################################
for row in  range(2,row_count):
    y = os.path.abspath("/opt/VM-DECOMM-AUTO/cvlt-delete-client.txt")
    file1 = open(y, 'a')
    file1.write("\n")
    file1.write((ws['A'+str(row)].value))
    file1.close()
os.system(' /bin/bash /opt/VM-DECOMM-AUTO/cvlt-delete-client.sh')




#######################################################################
#### Add data to "/etc/ansible/delete-servers.txt"  file
#######################################################################
for row in  range(2,row_count):
#     VMname = ws['A' + str(row)].value
#     vchk = vmname_check()
    x = os.path.abspath("/etc/ansible/delete-servers.txt")
    file1 = open(x, 'a')
    file1.write("\n")
    file1.write((ws['A'+str(row)].value))
    file1.close()
#####################################################################
#### Add data to "/etc/ansible/delete-answerfile.yml"  file ###############
#####################################################################
    textToReplace = ws['B'+ str(row)].value
#    print(textToReplace)
    textToSearch = "VCENTER-NAME"
    fileToSearch = '/etc/ansible/delete-answerfile.yml'
    tempFile = open( fileToSearch, 'r+' )
    for line in fileinput.input( fileToSearch ):
        tempFile.write( line.replace( textToSearch, textToReplace)  )

#####################################################################
#### Execute the Ansible Play-book and revert back the files 
#####################################################################
    tempFile.close()
    os.system('/bin/bash /opt/VM-DECOMM-AUTO/export.sh')
    os.system(' cat /etc/ansible/delete-servers.txt-template > /etc/ansible/delete-servers.txt')
    os.system(' cp -f /etc/ansible/delete-answerfile.yml-template /etc/ansible/delete-answerfile.yml')

# Close the workbook after reading
wb.close()
os.system('/bin/bash  delete-final-result.sh')
os.system('cat /opt/VM-DECOMM-AUTO/export-template.sh > /opt/VM-DECOMM-AUTO/export.sh')
os.system(' cat /dev/null > /opt/VM-DECOMM-AUTO/cvlt-delete-client.txt')
os.system(' cat /dev/null > /opt/VM-DECOMM-AUTO/BigFix-delete-client.txt')
os.system('/bin/chattr -i /apps/sre-share/vm-delete.xlsx')
