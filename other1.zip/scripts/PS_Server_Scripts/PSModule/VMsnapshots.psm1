﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 1:13 AM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -STARTED" | out-file -filepath $Logfile -Append

function Connect-SessionVC
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param (
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenter,
		[switch]$l
	)
	
	BEGIN
	{
		#$Key = New-Object Byte[] 32
		#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
		#$Key | out-file E:\scripts\aes.key
		#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
	}
	PROCESS
	{
		Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -ErrorAction:SilentlyContinue
		Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false -ErrorAction:SilentlyContinue
		Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false -ErrorAction:SilentlyContinue
		if ($l)
		{
			$encPw = Get-Content .\pwds.txt | ConvertTo-SecureString -key (Get-Content .\aes.key) #--> LocalTest
			$crede = New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User", $encPw)
		}
		else
		{
			$encPw = Get-Content e:\scripts\pwds.txt | ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key) #--> Server
			$crede = New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User", $encPw)
		}
		
		if (Connect-VIServer -Credential $crede -Server $vcenter.split(',')) #-force -ErrorAction:SilentlyContinue)
		{ Return $true }
		else
		{
			Return $false
		}
	}
	END
	{
		#No action required
	}
}

function Disconnect-SessionVC
{
	[CmdletBinding()]
	[OutputType([switch])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[switch]$a
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$dHold = Disconnect-VIServer * -Force -confirm:$false -ea SilentlyContinue
	}
	END
	{
		Return $dHold
	}
	
}

function Test-FlagInput
{
	[CmdletBinding()]
	[OutputType([string])]
	param (
		[Parameter(Position = 0, ValueFromPipeline = $true, Mandatory = $true)]
		[psobject]$parmInfo
	)
	
	begin
	{
		$cmdInfo = $parmInfo.psobject.copy() #copy Parms
		[string]$flagSwitch = $null
		foreach ($property in $cmdInfo.Keys)
		{
			if ($cmdInfo.$property.GetType().Name -eq 'SwitchParameter')
			{
				$flagSwitch = $property
			}
		}
	}
	process
	{
		if (($flagSwitch | Where-Object -FilterScript { $_ -eq $true }).count -gt 1)
		{
			Write-Error -Message "Error: Too many flag values." -Category InvalidArgument
			exit
		}
		else
		{
			return $flagSwitch
		}
	}
	end
	{
		# Do Nothing
	}
}

function Test-FileLock
{
	[CmdletBinding()]
	[OutputType([bool])]
	param (
		[Parameter(Position = 0, Mandatory = $true)]
		[System.String]$path
	)
	begin
	{
		#do nothing
	}
	process
	{
		$oFile = New-Object System.IO.FileInfo $path
		
		if ((Test-Path -Path $path) -eq $false)
		{ Return $false }
		try
		{
			$oStream = $oFile.open([System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
			
			if ($oStream)
			{
				$oStream.Close()
			}
			Return $false
		}
		catch
		{
			#File is Locked by a process
			return $true
		}
	}
	end
	{
		#do nothing
	}
}

function Write-log
{
	[CmdletBinding()]
	[OutputType([bool])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[psobject]$snapout,
		[Parameter(Position = 1, Mandatory = $true)]
		[System.String]$path
	)
	
	BEGIN
	{
		# Do Nothing
	}
	PROCESS
	{
		if (Test-FileLock -path $path)
		{
			return $false
		}
		else
		{
			$snapout | Out-File -Append $path -Force -ea SilentlyContinue
			return $true
		}
	}
	END
	{
		# Do Nothing
	}
}

function Get-VMAvailable
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		if ($vminfo.vim -eq $null)
		{
			$VMHold = Get-VM -Server $vminfo.vcenter -name $vminfo.vm -ea SilentlyContinue
			if ($null -ne $VMHold)
			{
				$vminfo.vim = $VMHold
				$vminfo.message = "SSC"
				return $vminfo
			}
			else
			{
				$vminfo.message = "SSF"
				return $vminfo
			}get
		}
		else
		{
			$vminfo.message = "SSC"
			return $vminfo
		}
	}
	END
	{
		# Nothing
	}
}

function Add-Snapshot
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	BEGIN
	{
		# Do nothing
	}
	
	PROCESS
	{
		if ($vminfo.message -eq "SSC")
		{
			try
			{
				$Snapshotdesc = $vminfo.pd + '_' + $vminfo.vm + '_Pace'
				$dHold = $vminfo.vim | New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc -ea SilentlyContinue
				$vminfo.message = "SSC"
				Return $vminfo
			}
			
			catch
			{
				$vminfo.message = "SSF"
				return $vminfo
			}
		}
		else
		{
			$vminfo.message = "SSF"
			return $vminfo
		}
	}
	END
	{
		#No action required
	}
	
}

function Get-Dsspace
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	BEGIN
	{
		#Do Nothing
	}
	
	PROCESS
	{
		if ($vminfo.message -eq "SSC")
		{
			$thresholds = "{0:n2}" -f 10
			$dsfreespace = get-datastore -VM $vminfo.vm -ea SilentlyContinue | select-object @{ N = "DSFreespace"; E = { [math]::Round(($_.FreeSpaceGB)/($_.CapacityGB) * 100, 2) } } | Select-Object -ExpandProperty DSFreespace
			#			Write-Host "datastore free space $vm $dsfreespace "
			#			Write-Host "datastore thresholds  $tresholds"
			if (($dsfreespace -gt $thresholds))
			{
				##				Write-Host "can take a snapshot. Datastore free space is higher than 10% $vm"
				$vminfo.message = "SSC"
				return $vminfo
			}
			else #				Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
			{
				#			Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
				$vminfo.message = "SSF"
				return $vminfo
			}
		}
		else
		{
			$vminfo.message = "SSF"
			return $vminfo
		}
		
	}
	END
	{
		# Do Nothing
	}
}

function Get-SnapStatus
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		if ($vminfo.message -eq "SSC")
		{
			$ExistingSnapshot = $vminfo.vim | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue
			if ($ExistingSnapshot)
			{
				$vminfo.message = "SSC"
				Return $vminfo
			}
			else
			{
				$vminfo.message = "SSF"
				Return $vminfo
			}
		}
		else
		{
			$vminfo.message = "SSF"
			Return $vminfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Remove-SnapShotVM
{
	[CmdletBinding(SupportsShouldProcess)]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		if ($vminfo.message -eq "Remove")
		{
			$ExistingSnapshot = Get-VM -Name $vminfo.vm -ea SilentlyContinue | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue | Remove-Snapshot -Confirm:$False -ea SilentlyContinue
			$pkid = $vminfo.pd
			if ($ExistingSnapshot)
			{
				$vmInfo.message = "SSF"
				Return $vmInfo
			}
			else
			{
				$vmInfo.message = "SSC"
				Return $vmInfo
			}
		}
		else
		{
			$vmInfo.message = "SSF"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Set-Output
{
	[CmdletBinding()]
	[OutputType([psobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[psobject]$StampArray,
		[Parameter(Position = 1, Mandatory = $true)]
		[System.String]$flag,
		[Parameter(Position = 2)]
		[System.String]$pdInfo,
		[System.String]$del
	)
	begin
	{
		#Do nothing
	}
	process
	{
		$StampInfo = $StampArray.psobject.copy() #copy Parms
		# SCS: SCRIPT -STARTED
		# SSS: SNAPSHOT_STS- STARTED
		# SSC: SNAPSHOT_STS- COMPLETED
		# SSF: SNAPSHOT_STS- FAILED
		# SCC: SCRIPT -COMPLETED
		switch ($del)
		{
			a {
				switch ($flag)
				{
					SCS {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED`r`n"
					}
					SCC {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -COMPLETED`r`n"
					}
					SSS {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_STS- STARTED`r`n"
					}
					SSC {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_STS- COMPLETED`r`n"
					}
					SSF {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_STS- FAILED`r`n"
					}
				}
			}
			d {
				switch ($flag)
				{
					SCS {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED`r`n"
					}
					SCC {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -COMPLETED`r`n"
					}
					SSS {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_REMOVE- STARTED`r`n"
					}
					SSC {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_REMOVE- COMPLETED`r`n"
					}
					SSF {
						$StampInfo += "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pdInfo - SNAPSHOT_REMOVE- FAILED`r`n"
					}
				}
			}
		}
	}
	end
	{
		Return $StampInfo
	}
}

function Get-AllVMSnapshot
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vmInfo #New
	)
	
	begin
	{
		# Do nothing
	}
	process
	{
		#$vminfo = $vmInfoNew.psobject.copy()
		
		if ($vminfo.vcconnect)
		{
			#Check VM availabel | Checkdisk for Snapshot  | takesnapshot
			$output = $vminfo | Get-VMAvailable | Get-Dsspace | Add-Snapshot | Get-SnapStatus
			return $output
		}
		else
		{
			$vminfo.message = "SSF"
			return $vminfo
		}
	}
	end
	{
		#Do Nothing
	}
}

Export-ModuleMember -Function *