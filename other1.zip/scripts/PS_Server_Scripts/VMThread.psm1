﻿#Version 2.0 - Sean Li seli@equinix.com

function Connect-SessionVC
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC,
		[Parameter(Mandatory = $true,
				   Position = 1)]
		[string]$userSVC,
		[Parameter(Mandatory = $true,
				   Position = 2)]
		[string]$passwordSVC
	)
	
	BEGIN
	{
		[securestring]$secPassword = ConvertTo-SecureString $passwordSVC -AsPlainText -force -ErrorAction:SilentlyContinue
		[pscredential]$credObject = New-Object System.Management.Automation.PSCredential ($userSVC, $secPassword)
	}
	PROCESS
	{
		if (Connect-VIServer -Server $vcenterSVC -Protocol https -Credential $credObject -ErrorAction:SilentlyContinue) { Return $true }
		else { Return $false }
	}
	END
	{
		Return $false
	}
}


function Disconnect-SessionVC
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$DicCon = Disconnect-VIServer -Server $vcenterSVC -Confirm:$false
		Remove-Module -Name VMware.VimAutomation.Core -ErrorAction:SilentlyContinue
	}
	END
	{
		return $DicCon
	}
}

function Get-StatusVM
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vmNameSVM
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$VMInfo = Get-VM -Name $vmNameSVM -ErrorAction:SilentlyContinue
		if ($VMInfo.PowerState -eq "PoweredOn")
		{
			$ToolsStatus = ($VMInfo | Get-View).Guest.ToolsStatus
			return [pscustomobject]@{
				VM	   = $vmNameSVM
				Status = [string]$ToolsStatus
			}
		}
		else
		{
			return [pscustomobject]@{
				VM	   = $vmNameSVM
				Status = [string]$VMInfo.PowerState
			}
		}
	}
	END
	{
		# Nothing
	}
}

function Get-SRMList
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$tag
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$vmTagList = Get-VM -Tag $tag
		return $vmTagList
	}
	END
	{
		# Nothing
	}
}

function Get-SrmVmStatus
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject[]]$runInfo
	)
	
	BEGIN
	{
		# Do Nothing
	}
	PROCESS
	{
		$vcConnection = Connect-SessionVC -vcenterSVC $runInfo.vcenter -userSVC $runInfo.user -passwordSVC $runInfo.password
		
		if ($vcConnection)
		{
			($runInfo.tag | Get-SRMList | Get-StatusVM) | Write-Output
			Disconnect-SessionVC -vcenterSVC $runInfo.vcenter | Write-Output
		}
		else
		{
			Disconnect-SessionVC -vcenterSVC $runInfo.vcenter | Write-Output
		}
	}
	END
	{
		# nothing
	}
}

Export-ModuleMember -Function Get-SrmVmStatus