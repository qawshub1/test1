﻿$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) + 'Current connections after creating snapshots:'" $Global:DefaultVIServers.count /n | out-file -filepath $Logfile -Append
Write-Host "Current connections after creating snapshots:"
$Global:DefaultVIServers.count