﻿#$Logfile = "c:\logs\snapshotCreationlog.txt"
$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#$file = "c:\temp\hostname.txt"
#$content = Get-Content $file
$Snapshotdesc ="testiung"
$vm= "test"
$tz= "UTC"
##Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
Add-Content -Path $Logfile -value "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED"