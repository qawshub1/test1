﻿#$Key = New-Object Byte[] 32
#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
#$Key | out-file E:\scripts\old\aes.key
#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\old\aes.key) | set-content "E:\scripts\old\pwds.txt"
#$crid = Get-Credential
#$crid.Password | ConvertFrom-SecureString | Set-Content e:\scripts\old\pwds.txt
#Write-Host "created password"

$encPw =Get-Content e:\scripts\pwds.txt |  ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
$crede =New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User",$encPw)
write-host "connecting"
Connect-VIServer -Credential $crede -Server sv2wnvcsrv01.global.equinix.com, ch3wnvcsrv04.global.equinix.com
#write-host $securestring












#Connect-VIServer  -User "Global\AMP-Admin-User" -password $securestring  -Server sv2wnvcsrv01.global.equinix.com

#$VCcred = Import-Clixml E:\scripts\VCCred.xml
#$Vcname = "sv2wnvcsrv01.global.equinix.co
#Connect-VIServer -Credential $VCcred -Server sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com
