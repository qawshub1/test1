﻿$global:test1 = $true
Try

{
#$Key = New-Object Byte[] 32
#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
#$Key | out-file E:\scripts\aes.key
#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -Confirm:$false
$tz= "UTC"
$Logfile = "E:\logs\ospatchSnapshotCreationlog.txt"
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$file = "E:\VMfolder\hostname.txt"
$content = Get-Content $file
$encPw =Get-Content e:\scripts\pwds.txt |  ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
$crede =New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User",$encPw)

Connect-VIServer -Credential $crede -Server sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com,vcenter.sddc-13-52-195-209.vmwarevmc.com,vcenter.sddc-13-52-169-49.vmwarevmc.com


foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED" | out-file -filepath $Logfile -Append
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
$counter =0
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
Start-Sleep 20
do
  {

$ExistingSnapshot = get-snapshot -vm $vm 
$counter += 1
Start-Sleep 10
  } until ($ExistingSnapshot -or $counter -ge 10)
  
 
  }
else
  {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
  }

if ($ExistingSnapshot -AND $Exists)
 {
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED" | out-file -filepath $Logfile -Append
 }
else 
 {
 Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
 }
}
 
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}
catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }