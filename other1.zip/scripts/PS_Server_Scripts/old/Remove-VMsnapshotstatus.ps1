﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/21/2021 4:00 PM
	 Created by:   	ramsubramanian & Sean Li
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$activeSwitch = 'd'
$global:ProgressPreference = 'SilentlyContinue'
Import-Module -Name 'E:\scripts\PSModule\VMsnapshots.psm1' -Scope Local # -->E:\scripts\PSModule\VMsnapshots.psm1
Import-Module -name VMware.VimAutomation.Core -Scope Local

$vcenter = [string] "ch3wnvcsrv04.global.equinix.com,sv2wnvcsrv01.global.equinix.com,vcenter.sddc-13-52-195-209.vmwarevmc.com,vcenter.sddc-13-52-169-49.vmwarevmc.com"

$file = "E:\RMfolder\hostname.txt" # ---> Server E:\VMfolder\
$logfile = "E:\logs\ospatchSnapshotRemoval_$(Get-Date -Format yyyyMMdd_HHmmss).log" #--> Server E:\logs\
$content = Get-Content $file
$VMListFile = @()
$vmHoldPd = @()
$vmHoldSv = @()
$outPut = @()
for ($index = 0; $index -lt $content.count; $index++) { $vmHoldPd += $content.split(",")[$index].split("|")[0] }
for ($index = 0; $index -lt $content.count; $index++) { $VMListFile += $content.split(",")[$index].split("|")[1] }

$ConnectState = Connect-SessionVC $vcenter

$vmHoldSv = $VMListFile | ForEach-Object { Get-VM -Name $_ } #  $vmInfo.vm.split(',')
$vmHoldVc = $vmHoldSv | ForEach-Object { $_.Uid.split(":")[0].split("@")[1] }

for ($index = 0; $index -lt $content.count; $index++)
{
	$vminfo = @()
	$ErrorMessage = ""
	$vminfo = [pscustomobject]@{
		vcenter = $vmHoldVc[$index]
		vm	    = $vmHoldSv[$index]
		pd	    = $vmHoldPd[$index]
		vcconnect = $ConnectState
		message = $ErrorMessage
	}
	
	if ($Global:DefaultVIServers | Select-String -Pattern $vmHoldVc[$index])
	{
		switch ($activeSwitch)
		{
			a {
				$vmHoldMg = $vminfo | Get-AllVMSnapshot #--Switch Add
			}
			d {
				$vmHoldMg = $vminfo | Remove-SnapShotVM #-- Switch Delete
			}
			default {
				$vmHoldMg.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT FAILED"
			}
		}
	}
	else
	{
		$vmHoldMg.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT FAILED"
	}
	$Output += $vmHoldMg.message
}

$DHold = Disconnect-SessionVC -a
$DHold = $outPut | Write-log -path $logfile
Import-Module 'E:\scripts\PSModule\VMsnapshots.psm1' -Force -Prefix PS