﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 1:13 AM
	 Created by:   	ramsubramanian & Sean Li
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -STARTED" | out-file -filepath $Logfile -Append

function Connect-SessionVC
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param (
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenter
	)
	
	BEGIN
	{
		#$Key = New-Object Byte[] 32
		#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
		#$Key | out-file E:\scripts\aes.key
		#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
	}
	PROCESS
	{
		Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -ErrorAction:SilentlyContinue
		Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false -ErrorAction:SilentlyContinue
		Set-PowerCLIConfiguration -DefaultVIServerMode multiple -Scope User -Confirm:$false -ErrorAction:SilentlyContinue
		$encPw = Get-Content e:\scripts\pwds.txt | ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key) #--> server e:\scripts
		$crede = New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User", $encPw)
		#$crede = Import-Clixml c:\scripts\VCCred.xml
		
		if (Connect-VIServer -Credential $crede -Server $vcenter.split(',') -force -ErrorAction:SilentlyContinue)
		{ Return $true }
		else
		{
			Return $false
		}
	}
	END
	{
		#No action required
	}
}

function Disconnect-SessionVC
{
	[CmdletBinding()]
	[OutputType([switch])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[switch]$a
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$dHold = Disconnect-VIServer * -Force -confirm:$false -ea SilentlyContinue
	}
	END
	{
		Return $dHold
	}
	
}

function Test-FileLock
{
	[CmdletBinding()]
	[OutputType([bool])]
	param (
		[Parameter(Position = 0, Mandatory = $true)]
		[System.String]$path
	)
	begin
	{
		#do nothing
	}
	process
	{
		$oFile = New-Object System.IO.FileInfo $path
		
		if ((Test-Path -Path $path) -eq $false)
		{ Return $false }
		try
		{
			$oStream = $oFile.open([System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
			
			if ($oStream)
			{
				$oStream.Close()
			}
			Return $false
		}
		catch
		{
			#File is Locked by a process
			return $true
		}
	}
	end
	{
		#do nothing
	}
}

function Write-log
{
	[CmdletBinding()]
	[OutputType([bool])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[psobject]$snapout,
		[Parameter(Position = 1, Mandatory = $true)]
		[System.String]$path
	)
	
	BEGIN
	{
		# Do Nothing
	}
	PROCESS
	{
		if (Test-FileLock -path $path)
		{
			return $false
		}
		else
		{
			$snapout | Out-File -Append $path -Force -ea SilentlyContinue
			return $true
		}
	}
	END
	{
		# Do Nothing
	}
}

function Get-VMAvailable
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		if ($null -ne (Get-VM -name $vminfo.vm -ea SilentlyContinue)) { return $vminfo }
		else
		{
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) + '-' + $vminfo.vm + 'Not Found'"
			Exit
		}
	}
	END
	{
		# Nothing
	}
}

function Add-Snapshot
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	BEGIN
	{
		# Do nothing
	}
	
	PROCESS
	{
		try
		{
			$Snapshotdesc = $vminfo.pd + '_' + $vminfo.vm + '_Pace'
			Get-VM $vminfo.vm | New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc -ea SilentlyContinue
			$pkid = $vminfo.pd
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_STS- STARTED"
			Return $vminfo
		}
		
		catch
		{
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT FAILED"
			return 'Error:' + $_.Exception.Message
		}
	}
	END
	{
		#No action required
	}
	
}

function Get-Dsspace
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	BEGIN
	{
		#connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
	}
	
	PROCESS
	{
		$thresholds = "{0:n2}" -f 10
		$dsfreespace = get-datastore -VM $vminfo.vm | select-object @{ N = "DSFreespace"; E = { [math]::Round(($_.FreeSpaceGB)/($_.CapacityGB) * 100, 2) } } | Select-Object -ExpandProperty DSFreespace
		#			Write-Host "datastore free space $vm $dsfreespace "
		#			Write-Host "datastore thresholds  $tresholds"
		if (($dsfreespace -gt $thresholds))
		{
			##				Write-Host "can take a snapshot. Datastore free space is higher than 10% $vm"
			return $vminfo
		}
		else #				Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
		{
			#			Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
			$vmid = $vminfo.vm
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss")) + ' UTC ' + $((Get-Date).ToUniversalTime().ToString("yyyy")) -  $vmid  Datastore free space is less than 10 percentage "
			Exit
		}
	}
	END
	{
		
	}
}

function Get-SnapShotVM
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vmInfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		if ($vmInfo.Message | Select-string -Pattern 'STARTED' -SimpleMatch)
		{
			
			$ExistingSnapshot = Get-VM -name $vminfo.vm | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue
			$pkid = $vminfo.pd
			
			if ($ExistingSnapshot)
			{
				$vmInfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_STS- COMPLETED"
				Return $vmInfo
			}
			else
			{
				$vmInfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_STS- NOT COMPLETED"
				Return $vmInfo
			}
		}
		elseif ($vmInfo.Message | Select-string -Pattern 'FAILED' -SimpleMatch)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_STS- FAILED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Remove-SnapShotVM
{
	[CmdletBinding(SupportsShouldProcess)]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		$ExistingSnapshot = Get-VM -name $vminfo.vm | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') | Remove-Snapshot -Confirm:$False -ea SilentlyContinue
		$pkid = $vminfo.pd
		if ($ExistingSnapshot)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_REMOVE- NOT COMPLETED"
			Return $vmInfo
		}
		else
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_REMOVE- COMPLETED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function New-SnapShotVM
{
	[CmdletBinding(SupportsShouldProcess)]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		$ExistingSnapshot = Get-VM -name $vminfo.vm | New-Snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue
		$pkid = $vminfo.pd
		if ($ExistingSnapshot)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_CREATE- COMPLETED"
			Return $vmInfo
		}
		else
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $pkid - SNAPSHOT_CREATE- NOT COMPLETED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Get-AllVMSnapshot
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscustomobject]$vmInfoNew
	)
	
	begin
	{
		# Do nothing
	}
	process
	{
		$vminfo = $vmInfoNew.psobject.copy()
		
		if ($vminfo.vcconnect)
		{
			#Check VM availabel | Checkdisk for Snapshot  | takesnapshot
			$output = $vmInfo | Get-VMAvailable | Get-Dsspace | Add-Snapshot | Get-SnapShotVM
			return $output
		}
		else
		{
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $vminfo.venter + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - NOT CONNECTED"
			return $vminfo
		}
	}
	end
	{
		#Do Nothing
	}
}

Export-ModuleMember -Function *