﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 5:28 PM
	 Created by:   	Sean Li
	 Organization: 	equinix
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#Version 2.0 - Sean Li seli@equinix.com

$activeSwitch = 'd' # Add or Delete Snapshot

$activeLocal = $false

$global:ProgressPreference = 'SilentlyContinue'
if ($activeLocal)
{
	Import-Module -Name .\VMsnapshots.psm1 -Scope Local # --> Local Testing
	Import-Module -name VMware.VimAutomation.Core -Scope Local
}
else
{
	Import-Module -Name 'E:\scripts\PSModule\VMsnapshots.psm1' -Scope Local # --> Server path
	Import-Module -name VMware.VimAutomation.Core -Scope Local
}

switch ($activeSwitch)
{
	a {
		if ($activeLocal)
		{
			$vmfile = ".\hostname.txt" # ---> LocalTest
			$vcenterlist = ".\vCenterList.txt"
			$logfile = ".\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log" #--> Local test
		}
		else
		{
			$vmfile = "E:\VMfolder\hostname.txt" # ---> Server
			$vcenterlist = "E:\scripts\vCenterList.txt"
			$logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log" #--> Server
		}
	}
	d {
		if ($activeLocal)
		{
			$vmfile = ".\hostname.txt" # ---> LocalTest
			$vcenterlist = ".\vCenterList.txt"
			$logfile = ".\ospatchSnapshotRemoval_$(Get-Date -Format yyyyMMdd_HHmmss).log" #--> Server E:\logs\
		}
		else
		{
			$vmfile = "E:\RMfolder\hostname.txt" # ---> Server
			$vcenterlist = "E:\scripts\vCenterList.txt"
			$logfile = "E:\logs\ospatchSnapshotRemoval_$(Get-Date -Format yyyyMMdd_HHmmss).log" #--> Server E:\logs\
		}
	}
}

$vcenter = Get-Content $vcenterlist
$content = Get-Content $vmfile

$VMListFile = @()
$vmHoldPd = @()
$vmHoldSv = @()
$TimeList = @()

for ($index = 0; $index -lt $content.count; $index++) { $vmHoldPd += $content.split(",")[$index].split("|")[0] }
for ($index = 0; $index -lt $content.count; $index++) { $VMListFile += $content.split(",")[$index].split("|")[1] }

if ($activeLocal)
{
	$ConnectState = Connect-SessionVC $vcenter -l
}
else
{
	$ConnectState = Connect-SessionVC $vcenter
}

$vmHoldSv = $VMListFile | ForEach-Object { Get-VM $_ -ea SilentlyContinue } #  $vmInfo.vm.split(',')
$vmHoldVc = $vmHoldSv | ForEach-Object { $_.Uid.split(":")[0].split("@")[1] }

$TimeList = Set-Output -StampArray $TimeList -flag SCS -del $activeSwitch
for ($index = 0; $index -lt $content.count; $index++)
{
	$vminfo = @()
	$Message = ""
	$vminfo = [pscustomobject]@{
		vcenter = $vmHoldVc[$index]
		vm	    = $VMListFile[$index]
		pd	    = $vmHoldPd[$index]
		vcconnect = $ConnectState
		message = $Message
		vim	    = [VMware.VimAutomation.ViCore.Types.V1.Inventory.VirtualMachine]$vmHoldSv[$index]
	}
	
	$TimeList = Set-Output -StampArray $TimeList -flag SSS -pdInfo $vmHoldPd[$index] -del $activeSwitch
	
	if ($Global:DefaultVIServers | Select-String -Pattern $vmHoldVc[$index])
	{
		switch ($activeSwitch)
		{
			a {
#				$vmHoldMg = $vminfo.psobject.copy() #--For Testing
#				$vmHoldMg.message = "SSC" #--For Testing
				$vmHoldMg = $vminfo | Get-AllVMSnapshot #--Switch Add
				$TimeList = Set-Output -StampArray $TimeList -flag $vmHoldMg.message -pdInfo $vmHoldPd[$index] -del $activeSwitch
			}
			d {
				$vminfo.message = "Remove"
#				$vmHoldMg = $vminfo.psobject.copy() #--For Testing
#				$vmHoldMg.message = "SSC" #--For Testing
				$vmHoldMg = $vminfo | Remove-SnapShotVM #-- Switch Delete
				$TimeList = Set-Output -StampArray $TimeList -flag $vmHoldMg.message -pdInfo $vmHoldPd[$index] -del $activeSwitch
			}
		}
	}
	else
	{
		$TimeList = Set-Output -StampArray $TimeList -flag SSF -pdInfo $vmHoldPd[$index] -del $activeSwitch
	}
	
}
$TimeList = Set-Output -StampArray $TimeList -flag SCC -del $activeSwitch
#Return $TimeList
$DHold = Disconnect-SessionVC -a
$DHold = $TimeList | Write-log -path $logfile
if ($activeLocal)
{
	Import-Module -Name .\VMsnapshots.psm1 -Force -Prefix PS # --> Local Testing
}
else
{
	Import-Module -Name "E:\scripts\PSModule\VMsnapshots.psm1" -Force -Prefix PS # --> Server path
}