﻿#Version 2.0 - Sean Li seli@equinix.com

[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$vm,
	[Parameter(Mandatory, Position = 2)]
	[string]$user,
	[Parameter(Mandatory, Position = 3)]
	[string]$password
)

Import-Module -Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\VMThread.psm1' -Scope Local
Import-Module -Name VMware.VimAutomation.Core -Scope Local

if (Connect-SessionVC -vcenterSVC $vcenter -userSVC $user -passwordSVC $password)
{
	Write-Output "Connected"
	$VMStatusCheck = Get-StatusVM $vm
	Write-Output $VMStatusCheck
#	$VMInfo = Get-VM -Name $vm
#	Write-Output $VMInfo
#	$vmView = ($VMInfo | Get-View).Guest.IPAdress
	#	Write-Output $vmView
	$vmip = '10.249.15.100'
	$Service = get-wmiobject -ComputerName $vmip -query "select * from win32_service where name='VMTools'"
	Write-Output $Service
	Write-Host "Starting services on $vm"
	#Start the VMTools Service
	$Service.StartService()
	
	
	#Write-Output $cmdInfo
	foreach ($property in $cmdInfo.Keys)
	{
		if ($cmdInfo.$property.GetType().Name -eq 'String')
		{
			if ($cmdInfo.$property -eq $null)
			{
				Write-Output 'Argument ' $Z ' missing info'
				exit
			}
		}
	}
}

}



Test-FlagInput








Disconnect-SessionVC -vcenterSVC $vcenter | Write-Output