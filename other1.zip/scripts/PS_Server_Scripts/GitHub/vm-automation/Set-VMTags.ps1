﻿#Version 2.0 - Sean Li seli@equinix.com

[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$tag,
	[Parameter(Mandatory, Position = 2)]
	[string]$vm,
	[Parameter(Mandatory, Position = 3)]
	[string]$user,
	[Parameter(Mandatory, Position = 4)]
	[string]$password,
	[switch]$a,
	[switch]$d
)

#Import-Module -Name ThreadJob -RequiredVersion 2.0.3 -Scope Local
Import-Module -Name VMware.VimAutomation.Core -Scope Local # For testing
Import-Module -Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\VMThread.psm1' -Scope Local

function Set-VMTag {
	[CmdletBinding()]
	[OutputType([system.string])]
	param(
		[Parameter(Position=0, ValueFromPipeline = $true, Mandatory=$true)]
		[psobject]
		$tagInfo
	)
	
	begin
	{
		[string]$flagSwitch = $null
		foreach ($property in $tagInfo.Keys)
		{
			if ($tagInfo.$property.GetType().Name -eq 'SwitchParameter')
			{
				$flagSwitch = $property
			}
		}
				$vcConnection = Connect-SessionVC -vcenterSVC $tagInfo.vcenter -userSVC $tagInfo.user -passwordSVC $tagInfo.password
	}
	process
	{
		switch ($flagSwitch) {
			a {
				Write-Output $flagSwitch
			}
			c {
				Write-Output $flagSwitch
			}
			d {
				Write-Output $flagSwitch
			}
			u {
				Write-Output $flagSwitch
			}
			default {
				$findTag = Get-VM -Server $tagInfo.vcenter -Name $tagInfo.vm | Get-TagAssignment | Where-Object -FilterScript { $_ -eq 'Name' }
				Write-Output 'get tag from VM:'$findTag
			}
		}
#		Write-Output $tagInfo.keys.name
		if ($vcConnection)
		{
			Write-Output $tagInfo
		}
	}
	end
	{
		Disconnect-SessionVC -vcenterSVC $tagInfo.vcenter | Write-Output
	}
}
#End Functions
[string[]]$vcenterApi = $vcenter.Split(',')
[psobject]$threadInfo = $PSCmdlet.MyInvocation.BoundParameters
$holdFlag = Test-FlagInput $threadInfo

for ($index = 0; $index -lt $vcenterApi.count; $index++)
{
	Set-VMTag $threadInfo
	#$holdJob = Start-ThreadJob -InitializationScript { Import-Module -Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\VMThread.psm1' -Scope Local; Import-Module -Name VMware.VimAutomation.Core -Scope Local } -ScriptBlock { Get-ListStatusVM $using:threadInfo }
}

#$outPut = Get-Job | Wait-Job | Receive-Job | ConvertTo-Json
#return $outPut