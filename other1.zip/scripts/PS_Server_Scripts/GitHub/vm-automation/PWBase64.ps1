﻿$PasswordCV = Read-Host -Promt 'Paswword To Convert Base 64'
$ENCODED = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($PasswordCV))
Write-Output "BAse64 Encoded Password '$ENCODED'"