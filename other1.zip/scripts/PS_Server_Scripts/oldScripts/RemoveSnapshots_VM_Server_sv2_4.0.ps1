﻿
$global:test1 = $true
Try

{
#$Key = New-Object Byte[] 32
#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
#$Key | out-file E:\scripts\aes.key
#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -Confirm:$false
$tz= "UTC"
$Logfile = "e:\logs\ospatchSnapshotRemovelog.txt"
$file = "e:\RMfolder\hostname.txt"
$content = Get-Content $file
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$encPw =Get-Content e:\scripts\pwds.txt |  ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
$crede =New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User",$encPw)

Connect-VIServer -Credential $crede -Server sv2wnvcsrv01.global.equinix.com

foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)

$Exists = Get-VM -name $vm  -ErrorAction SilentlyContinue

if ($Exists)
 {
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_REMOVE_STS- STARTED " | out-file -filepath $Logfile -Append
Get-vm $vm  | get-snapshot | remove-snapshot -RunAsync -confirm:$false
Start-Sleep 60
$Snapshot= Get-vm $vm | get-snapshot -ea SilentlyContinue

 }
else
  {
Write-Output "$vm - VM NOT FOUND" | out-file -filepath $Logfile -Append

  }

if ($Snapshot -and $Exists)
 {
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_REMOVE_STS- FAILED - " | out-file -filepath $Logfile -Append
 }
else 

 {

 Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_REMOVE_STS- COMPLETED" | out-file -filepath $Logfile -Append
 }
}
 
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}

 
catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }




 


