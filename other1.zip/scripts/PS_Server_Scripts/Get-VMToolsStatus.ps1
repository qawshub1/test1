﻿#Version 2.0 - Sean Li seli@equinix.com

[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$tag,
	[Parameter(Mandatory, Position = 2)]
	[string]$user,
	[Parameter(Mandatory, Position = 3)]
	[string]$password
)

Import-Module -Name ThreadJob -RequiredVersion 2.0.3 -Scope Local
[string[]]$vcenterApi = $vcenter.Split(',');

for ($index = 0; $index -lt $vcenterApi.count; $index++)
{
	$threadInfo = [pscustomobject]@{
		vcenter = [string]$vcenterApi[$index]
		tag	    = [string]$tag
		user    = [string]$user
		password = [string]$password
	}
	
	$holdJob = Start-ThreadJob -InitializationScript { Import-Module E:\scripts\VMThread.psm1 -Scope Local; Import-Module -Name VMware.VimAutomation.Core -Scope Local } -ScriptBlock { Get-SrmVmStatus $using:threadInfo }
}

$outPut = Get-Job | Wait-Job | Receive-Job | ConvertTo-Json
return $outPut