$servers = Get-content -path "c:\temp\servers.txt"
$collection = @()

Foreach($server in $servers)
{
	if(Test-Connection -Server $server -Count 1 -ErrorAction SilentlyContinue)
	{
		$Ping = "True"
	}else
	{
		$Ping = "False"
	}

	$coll = "" | Select Server,Ping_Result
	$coll.Server = $server
	$coll.Ping_Result = $Ping
	
	$collection += $coll
}

$collection | Export-csv -path "C:\temp\Ping_ecobflun01.csv" -notypeinformation