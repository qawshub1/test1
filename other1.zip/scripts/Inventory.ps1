﻿connect-viserver sv2wnvcsrv01.global.equinix.com
$DateTime = $((Get-Date).ToString('yyyy-MM-dd_hh-mm-ss'))
$OutputPath = "C:\temp"

Set-Location $OutputPath

$VMList = $null
$VMList = Get-Cluster -Name sv2vmmgmt01| Get-VM
$VMList = $VMList | Sort-Object -Property Name # Sort the VM list on alphabetical order

$Counter = 1
$Report = @()

While ($Counter -lt $VMList.Count) {
    ForEach ($VM in $VMList) {
        Write-Host $Counter"/"($VMList).Count "[$VM]"

        $VMView = $VM | Get-View
        $VMNICs = (Get-NetworkAdapter -VM $VM)

        $VMInfo = { } | Select-Object Name, PowerState, HardwareVersion, vCenter, Host, Cluster, ToolsStatus, GuestOS, NumCPU, MemGB, NumNICs, NIC0Type, NIC0IP, NIC0Mac,Folder

        $VMInfo.Name = $VM.Name
        $VMInfo.HardwareVersion = $VM.HardwareVersion
        $VMInfo.ToolsStatus = $VMView.Guest.ToolsStatus
        $VMInfo.GuestOS = (Get-VMGuest -VM $VM).OSFullName
        $VMInfo.NumCPU = $VM.NumCpu
        $VMInfo.MemGB = $VM.MemoryGB
        $VMInfo.Host = $VM.VMHost.Name
        $VMInfo.Cluster = $VM.VMHost.Parent.name
        $VMInfo.Folder = $VM.Folder.Name
        $VMInfo.PowerState = $VM.PowerState
        $VMInfo.NumNICs = $VMNICs.Count
        $VMInfo.NIC0Type = $VMNICs.Type[0]
        $VMInfo.NIC0IP = $VM.Guest.IPAddress[0]
        $VMInfo.NIC0Mac = $VMNICs.MacAddress[0]
        $VMInfo.vCenter = $VM.Uid.Substring($VM.Uid.IndexOf('@') + 1).Split(":")[0]

        $Report += $VMInfo
        $Counter++
    }
}

$Report | Export-Csv "$Outputfile.csv" -NoTypeInformation -UseCulture