﻿#$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
#$vccred | Export-Clixml C:\scripts\VCCred.xml
Try
{
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sg1wnvcsrv03.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname
$snapshotVM = gci C:\testfolder | %{$_.BaseName} | sort lastwritetime
#$filename = (gci C:\testfolder | sort lastwritetime|Select-Object -First 1).name
$filename = (gci C:\testfolder | sort lastwritetime).name
$Snapshotdesc = 'PrePATCH'+ $snapshotVM +' '+ (Get-Date -Format "dd-MM-yyyy hh:MM:ss")
$file = "c:\temp\log.txt"
foreach($vm in $snapshotVM)
{
$Snapshotdesc = 'PrePATCH'+ $vm +' '+ (Get-Date -Format "dd-MM-yyyy hh:MM:ss")
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
Write-Output "SNAPSHOT_STS- STARTED $vm" | out-file -filepath $file -Append
write-host "SNAPSHOT_STS- STARTED $vm"  
Start-Sleep 30
#Get-VM $vm | get-snapshot | format-list vm,name,sizeMB,Created | out-file -filepath $file -Append
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ea SilentlyContinue
if ($ExistingSnapshot)
{
Get-VM $vm | get-snapshot | format-list vm,name,sizeMB,Created | out-file -filepath $file -Append
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:MM:ss")) $vm -SCRIPT-COMPLETED" | out-file -filepath $file -Append
}
else 
{
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:MM:ss")) $vm -SNAPSHOT_STS- FAILED" | out-file -filepath $file -Append
}
#mv c:\testfolder\$vm+".txt"  c:\completedVMs
}
#mv c:\testfolder\$filename  c:\completedVMs
}
catch
 {
  return 'Error:' + $_.Exception.Message  
 }
 
 





