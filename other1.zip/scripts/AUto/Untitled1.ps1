﻿#function Get-VMSnapshot{[CmdletBinding()]
#param  
#( 
#[Parameter(Mandatory=$false)] $vm1,    
#[Parameter(Mandatory=$false)] $Snapshotdesc 
#)
#}
$global:test1 = $true
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

$file = "c:\logs\snapshotCreationlog.txt"
$vm1 = "testram3"
$Snapshotdesc = "test-ram"
try
{

$ExistingSnapshot= get-snapshot -vm $vm1 -Name $Snapshotdesc -ErrorAction Stop | Out-Null -ea SilentlyContinue
if ($ExistingSnapshot)
{
#Get-VM $vm | get-snapshot | format-list vm,name,sizeMB,Created | out-file -filepath $file -Append 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm1 - SNAPSHOT-COMPLETED" | out-file -filepath $file -Append -ea SilentlyContinue
}

else
{
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm1 - SNAPSHOT-NOTFOUND" | out-file -filepath $file -Append -ea SilentlyContinue
}
}
catch
{
$global:test1 = $false
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm1 - VM-NOTFOUND" | out-file -filepath $file -Append
}
finally {
if($global:test1)
{
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm1 - VMfound" | out-file -filepath $file -Append
}
else 
{
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm1 - VMnotfound" | out-file -filepath $file -Append

}
}
