﻿#$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
#$vccred | Export-Clixml C:\scripts\VCCred.xml
$global:test1 = $true

Try

{

$Logfile = "c:\logs\snapshotremovallog.txt"
$file = "c:\temp\hostname.txt"
$content = Get-Content $file
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

#$snapshotVM = gci C:\RmSnapsfolder | %{$_.BaseName} | sort lastwritetime


foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)

$Exists = Get-VM -name $vm  -ErrorAction SilentlyContinue

if ($Exists)
 {
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -$vm - SNAPSHOT_REMOVE_STS- STARTED " | out-file -filepath $Logfile -Append
Get-vm $vm  | get-snapshot | remove-snapshot -RunAsync -confirm:$false
Start-Sleep 30
$Snapshot= Get-vm $vm | get-snapshot -ea SilentlyContinue

 }
else
  {
Write-Output "$vm - VM NOT FOUND" | out-file -filepath $Logfile -Append

  }

if ($Snapshot -and $Exists)
 {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd - $vm - SNAPSHOT_STS_Remove_FAILED - " | out-file -filepath $Logfile -Append
 }
else 

 {

 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -$vm - SNAPSHOT_STS_Remove Completed" | out-file -filepath $Logfile -Append
 }
}
 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}

 
catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }




 


