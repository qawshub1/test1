﻿$file = "c:\temp\test.txt"
$temp = Get-Content $file
foreach($tx in $temp)
{
$tx.split("|")
$pid = $nline.GetValue(0)
$nline.GetValue(1)
#write-host  "$pid"
#Write-host "-$pid -$vm - SNAPSHOT_STS- STARTED "


}
