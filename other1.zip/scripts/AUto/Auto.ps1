﻿$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
$vccred | Export-Clixml C:\scripts\VCCred.xml

$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sg1wnvcsrv03.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname
$snapshotVM = gci C:\testfolder | %{$_.BaseName} | sort lastwritetime
$filename = (gci C:\testfolder | sort lastwritetime|Select-Object -First 1).name
$Snapshotdesc = 'PrePATCH'+ $snapshotVM +' '+ (Get-Date -Format "dd-MM-yyyy hh:MM:ss")
Write-host  $snapshot
Write-host  $snapshotVM
write-host $filename
$NewSnapshot = New-Snapshot -VM $snapshotVM -Name $Snapshotdesc -Description $Snapshotdesc
mv $filename  c:\completedVMs





