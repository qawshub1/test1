﻿Start-Transcript -path $sPath\C\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log

##Start-Job  -ScriptBlock
{

#$Logfile = "c:\logs\snapshotCreationlog.txt"
#$Logfile = "C:\logs\ospatchSnapshotCreation__$(Get-Date -Format yyyyMMdd_HHmmss).log"


Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" 
#Add-Content -Path $Logfile -value "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED"



}
#Get-Job | Wait-Job
#Get-Job | Receive-Job -keepWrite-Output "$(Get-Date -Format F) - SCRIPT - COMPLETED"
Stop-Transcript