﻿$Logfile = "c:\logs\snapshotCreationlog.txt"
function connectVcenters()
 {
param(

 $VCname
     )
 process
 {

  try 
  {
  
   Write-Host "Connecting to vCenter $vcAddress..." -noNewLine
   Write-Host "Current connections:"
   $Global:DefaultVIServers.count
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $encPw =Get-Content e:\scripts\pwds.txt |  ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
   $crede =New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User",$encPw)
  foreach ($vc in $VCname)
    {
    Connect-VIServer -Credential $cred -Server $Vcname -ErrorAction:SilentlyContinue
   Write-Host -foreGroundColor Green "[Done]"
   Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append
    }
  }

catch
    {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

     }
      
   }
  }
function disconnectVcenters()
{

 try 
  {
   Write-Host "disconnecting  to vCenter $vcAddress..." -noNewLine
   Disconnect-VIServer * -Force -confirm:$false
   Write-Host -foreGroundColor Green "[Disconnected]"
   Write-Output " discconnected vcenter " | out-file -filepath $Logfile -Append
   Write-Host "Current connections:"
    $Global:DefaultVIServers.count
   }

catch
    {
     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notdisconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit
    }
}



function CreateSnapshots()

{

BEGIN
 {
Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope Session  -Confirm:$false
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED"
 }

PROCESS
 {
$tz= "UTC"
$file = "c:\temp\hostname.txt"
$content = Get-Content $file
 
 try
   {
connectVcenters -VCname sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com,vcenter.sddc-13-52-195-209.vmwarevmc.com, vcenter.sddc-13-52-169-49.vmwarevmc.com
Write-Host "Current connections:"
$Global:DefaultVIServers.count
foreach($name in $content)
    {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
$counter =0
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
do
   {

$ExistingSnapshot = get-snapshot -vm $vm 
$counter += 1
Start-Sleep 10
   } until ($ExistingSnapshot -or $counter -ge 10)


Write-Host "Current connections after creating snapshots $vm :"
    $Global:DefaultVIServers.count
  }
else
   {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
   }
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ErrorAction  SilentlyContinue
if ($ExistingSnapshot -AND $Exists)
   {
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED" | out-file -filepath $Logfile -Append

   }
else 
   {
   Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
    }
 }
disconnectVcenters
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append


 }

catch
    {
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append

  return 'Error:' + $_.Exception.Message 
     }

  }
END
	{
	   #No action required
	}


}
#connectVcenters -VCname sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com
#disconnectVcenters

#Start-ThreadJob  -ScriptBlock {CreateSnapshots}
#$outPut = Get-Job | Wait-Job | Receive-Job | ConvertTo-Json
#return $outPut

CreateSnapshots
#write-Host (Receive-Job test) -fore Green
#Remove-Job test
Write-Host "Current connections after creating snapshots:"
$Global:DefaultVIServers.count