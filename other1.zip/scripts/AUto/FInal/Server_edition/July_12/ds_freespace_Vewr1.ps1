﻿$Logfile = "c:\logs\snapshotCreationlog.txt"

function connectVcenters()
{
param(
 $VCname

 )
 process
 {

#Connect-VIServer -Credential $VCcred -Server $Vcname.
try 
  {
  
   Write-Host "Connecting to vCenter $vcAddress..." -noNewLine
   Write-Host "Current connections:"
    $Global:DefaultVIServers.count
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $VCcred = Import-Clixml c:\scripts\VCCred.xml
  # $Vcname = "sv2wnvcsrv01.global.equinix.com"

  foreach ($vc in $VCname)
  {
    Connect-VIServer -Credential $VCcred -Server $Vcname -ErrorAction:SilentlyContinue
   Write-Host -foreGroundColor Green "[Done]"
   Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append
  }
  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notconnectedconnected vcenter " | out-file -filepath $Logfile -Append

     exit

      }
      
  }
  }

  function Get-Dsspace()
  
  
  {
    [CmdletBinding()]
	[OutputType([boolean])]
    
  param 
  (
    $vmname
  )
  BEGIN
  {
  connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
  write-host "connected"
  }

  PROCESS
  {
  ForEach ($vm in $vmname ) 
  
   {
 
$thresholds = "{0:n2}" -f 10
$dsfreespace = get-datastore -VM $vm | select-object @{N="DSFreespace"; E={[math]::Round(($_.FreeSpaceGB)/($_.CapacityGB)*100,2)}} | Select-Object -ExpandProperty DSFreespace
Write-Host "datastore free space $vm $dsfreespace "
Write-Host "datastore thresholds  $tresholds"
if (($dsfreespace -gt $thresholds)) 
      {
Write-Host "You can take a snapshot. Datastore free space is higher than 10% $vm"
return $true
#new-snapshot -vm $vm -name test123
      }
 else
      {
Write-Host "You cannot take a snapshot. Datastore free space is lower than 10% $vm"
return $false
      }
   }
  }
  END
  {

  }
}



Get-Dsspace -vmname test8
