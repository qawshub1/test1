﻿#New-VICredentialStoreItem -host sv2wnvcsrv0quinix.co1.global.em -User Global\adm-ramsubramanian -password Eqixwed19052021$
#Get-VICredentialStoreItemsv2wnvcsrv01.global.equinix.comian\AppData\Roaming\VMware\credstore\vicredentials.xml
#Connect-VIServer sv2wnvcsrv01.global.equinix.com
#Remove-VICredentialStoreItem -Host v2wnvcsrv01.global.equinix.com -User Global\admramsubramanian

#New-VICredentialStoreItem -host vcenter.sddc-13-52-195-209.vmwarevmc.com  -User Global\adm-ramsubramanian -password Eqixwed19052021$
 #Connect-VIServer vcenter.sddc-13-52-195-209.vmwarevmc.com , sv2wnvcsrv01.global.equinix.com

 New-VICredentialStoreItem -host sv2wnvcsrv01.global.equinix.com -User Global\AMP-Admin-User -password "7LX4zVzC67^=t~Em}^/~"
 New-VICredentialStoreItem -host ch3wnvcsrv04.global.equinix.com -User Global\AMP-Admin-User -password "7LX4zVzC67^=t~Em}^/~"
 New-VICredentialStoreItem -host vcenter.sddc-13-52-195-209.vmwarevmc.com -User Global\AMP-Admin-User -password "7LX4zVzC67^=t~Em}^/~"
 New-VICredentialStoreItem -host vcenter.sddc-13-52-169-49.vmwarevmc.com -User Global\AMP-Admin-User -password "7LX4zVzC67^=t~Em}^/~"

# sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com,vcenter.sddc-13-52-195-209.vmwarevmc.com,vcenter.sddc-13-52-169-49.vmwarevmc.com
Connect-VIServer ch3wnvcsrv04.global.equinix.com