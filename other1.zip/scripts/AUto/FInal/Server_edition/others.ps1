﻿Start-Transcript -Path $sPath\ospatch\ospatch_$(Get-Date -Format yyyyMMdd_HHmmss).log
Write-Output "$(Get-Date -Format F) - SCRIPT -STARTED"
$hostfile = "$($sPath)\hostname.txt"
$serverlist = Import-Csv -Delimiter '|' $hostfile -Header 'pkid', 'hostname', 'stype'# Segregate by Server Type

$gtwy = $serverlist | Where-Object { $_.stype.ToLower() -eq 'gtwy' }
$app = $serverlist | Where-Object { $_.stype.ToLower() -eq 'app' }
$web = $serverlist | Where-Object { $_.stype.ToLower() -eq 'web' }
$scriptblock = 
{
 try 

{
Write-Output "$(Get-Date -Format F) - $($args[0]) - STARTUP_STS - STARTED
"Get-Service -ComputerName $args[1] -Name "$($args[2])" | Where-Object { $_.Status -eq 'Stopped' } | Start-Service -ErrorAction STO

Write-Output "$(Get-Date -Format F) - $($args[0]) - STARTUP_STS - COMPLETED"

}
catch
 
 {
 Write-Output "$(Get-Date -Format F) - $($args[0]) - STARTUP_STS - FAILED"}
 
 }
# Start Gateway Servers
$gtwy | ForEach-Object {
$arguments = @($_.pkid, $_.hostname, 'gtwyns')
Start-Job -Name $_.pkid -ScriptBlock $scriptblock -ArgumentList $arguments
}

# Start Gateway container
$gtwy | ForEach-Object 
 {
 $arguments = @($_.pkid, $_.hostname, 'SiebelApplicationContainer*')
Start-Job -Name $_.pkid -ScriptBlock $scriptblock -ArgumentList $arguments
}
# Waiting for Gateway to Start 
Get-Job | Wait-Job
# Start app containers
$app | ForEach-Object
 {
 $arguments = @($_.pkid, $_.hostname, 'SiebelApplicationContainer*')

Start-Job -Name $_.pkid -ScriptBlock $scriptblock -ArgumentList $arguments
}

# Waiting for app containers to StartGet-Job | Wait-Job
# Start Siebel Servers$app |
 ForEach-Object 
 {$arguments = @($_.pkid, $_.hostname, 'siebsrvr*')
 Start-Job -Name $_.pkid -ScriptBlock $scriptblock -ArgumentList $arguments
 }
 # Start Web Servers
 $web | ForEach-Object 

{
$arguments = @($_.pkid, $_.hostname, 'SiebelApplicationContainer*')
Start-Job -Name $_.pkid -ScriptBlock $scriptblock -ArgumentList $arguments
}
# Waiting for Services to StartWrite-Output "Waiting for Services to START...
"Get-Job | Wait-JobGet-Job | Receive-Job -keepWrite-Output "
"$(Get-Date -Format F) - SCRIPT - COMPLETED"
Stop-Transcript