﻿$global:test1 = $true
#$scriptblock = {

Start-Transcript -Path "c:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#


Try


{

$file = "c:\temp\hostname.txt"
$content = Get-Content $file
$Snapshotdesc ="testiung"
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" 
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - VC connected "

foreach($name in $content)
 {
 
 $inline = $args[0].split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED" | out-file -filepath $Logfile -Append
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED"


$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
$counter =0
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
Start-Sleep 20
do
  {

$ExistingSnapshot = get-snapshot -vm $vm 
$counter += 1
Start-Sleep 10
  } until ($ExistingSnapshot -or $counter -ge 10)
  
 
  }
else
  {
#Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
#Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append

Write-Output "$vm - NOT FOUND"
Write-Output "$vm - SNAPSHOT NOT CREATED"
  }
} 

if ($ExistingSnapshot -AND $Exists)
 {
#write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED" | out-file -filepath $Logfile -Append
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED"
 }
else 
 {
# Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
Write-Output" $((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- FAILED"
 }

 

#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED"
Disconnect-VIServer * -Force -confirm:$false
}
catch
 {
$global:test1 = $false
 #Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
 Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED"
  return 'Error:' + $_.Exception.Message 
 }
 
 #}
 Start-Job -ScriptBlock $scriptblock -ArgumentList $name
 Stop-Transcript