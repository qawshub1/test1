﻿$Logfile = "c:\logs\snapshotCreationlog.txt"

function connectVcenters()
{
param(
 $VCname

 )
 process
 {

#Connect-VIServer -Credential $VCcred -Server $Vcname.
try 
  {
  
   Write-Host "Connecting to vCenter $vcAddress..." -noNewLine
   Write-Host "Current connections:"
    $Global:DefaultVIServers.count
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $VCcred = Import-Clixml c:\scripts\VCCred.xml
  # $Vcname = "sv2wnvcsrv01.global.equinix.com"
    Connect-VIServer -Credential $VCcred -Server $Vcname -ErrorAction:SilentlyContinue
   Write-Host -foreGroundColor Green "[Done]"
   Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append

  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

      }
      
  }
  }
function disconnectVcenters()
{

try 
  {
  
   Write-Host "disconnecting  to vCenter $vcAddress..." -noNewLine

   Disconnect-VIServer * -Force -confirm:$false
   Write-Host -foreGroundColor Green "[Disconnected]"
   Write-Output " discconnected vcenter " | out-file -filepath $Logfile -Append

  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notdisconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

      }
}
connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
