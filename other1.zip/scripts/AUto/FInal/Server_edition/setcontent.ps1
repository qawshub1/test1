﻿$Logfile = "c:\logs\snapshotCreationlog.txt"
$file = "c:\temp\hostname.txt"
$content = Get-Content $file
$Snapshotdesc ="testiung"
$vm= "test"
$tz= "UTC"
##Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
Add-Content -Path $Logfile -value "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED"
##good one##Add-Content -Path $Logfile -value "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $vm + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -  - SNAPSHOT_STS- COMPLETED after coming out from do loop"

##write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $vm - SNAPSHOT_STS- STARTED"

Add-Content -Path $Logfile -value "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $vm - SNAPSHOT_STS- STARTED"



Add-Content -Path $Logfile -value "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED"

Add-Content -Path $Logfile -value "$vm - NOT FOUND"
Add-Content -Path $Logfile -value "$vm - SNAPSHOT NOT CREATED"
Add-Content -Path $Logfile -value "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED"

write-host "complete"