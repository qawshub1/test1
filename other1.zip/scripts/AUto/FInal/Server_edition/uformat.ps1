﻿$Logfile = "c:\logs\snapshotCreationlog.txt"
$tz= "UTC"
#$yr= (Get-Date).ToUniversalTime().ToString(
#$currenttime=$(Get-Date -AsUTC)
#Write-host $(Get-Date -uformat "%a %b %T") "$tp" $((Get-Date).ToString("yyyy"))
#Write-host $currenttime
#Write-Output $(Get-Date -uformat "%a %b %T") "UTC" | out-file -filepath $Logfile -Append
#(Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")


Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED"
