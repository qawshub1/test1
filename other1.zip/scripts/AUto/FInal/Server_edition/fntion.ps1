﻿$Logfile = "c:\logs\snapshotCreationlog.txt"

function connectVcenters()
{
 param(
 $VCname

 )
 process
 {
#Connect-VIServer -Credential $VCcred -Server $Vcname.
try 
  {
  
   Write-Host "Connecting to vCenter $vcAddress..." -noNewLine
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $VCcred = Import-Clixml c:\scripts\VCCred.xml
   $Vcname = "sv2wnvcsrv01.global.equinix.com"
   Connect-VIServer -Credential $VCcred -Server $Vcname -ErrorAction:SilentlyContinue
   Write-Host -foreGroundColor Green "[Done]"
   Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append

  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

      }
    }
      
  }

function disconnectVcenters()
{

try 
  {
  
   Write-Host "disconnecting  to vCenter $vcAddress..." -noNewLine

   Disconnect-VIServer * -Force -confirm:$false
   Write-Host -foreGroundColor Green "[Disconnected]"
   Write-Output " discconnected vcenter " | out-file -filepath $Logfile -Append

  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notdisconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

      }
}
function CreateSnapshots()

{
 try
 {

foreach($name in $content)
  {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc

Start-Sleep 30
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
   }
else
   {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
   }
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ErrorAction  SilentlyContinue
if ($ExistingSnapshot -AND $Exists)
   {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd - SNAPSHOT-COMPLETED" | out-file -filepath $Logfile -Append
   }
else 
   {
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
   }
  }
 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append


 }

catch
 {

 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }

}



