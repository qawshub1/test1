﻿$Logfile = "c:\logs\snapshotCreationlog.txt"

function connectVcenters()
{
param(
 $VCname

 )
 process
 {

#Connect-VIServer -Credential $VCcred -Server $Vcname.
try 
  {
  
   Write-Host "Connecting to vCenter $vcAddress..." -noNewLine
   Write-Host "Current connections:"
    $Global:DefaultVIServers.count
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $VCcred = Import-Clixml c:\scripts\VCCred.xml
  # $Vcname = "sv2wnvcsrv01.global.equinix.com"

  foreach ($vc in $VCname)
  {
    Connect-VIServer -Credential $VCcred -Server $Vcname -ErrorAction:SilentlyContinue
   Write-Host -foreGroundColor Green "[Done]"
   Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append
  }
  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notconnectedconnected vcenter " | out-file -filepath $Logfile -Append

     exit

      }
      
  }
  }
function disconnectVcenters()
{

try 
  {
  
   Write-Host "disconnecting  to vCenter $vcAddress..." -noNewLine

   Disconnect-VIServer * -Force -confirm:$false
   Write-Host -foreGroundColor Green "[Disconnected]"
   Write-Output " discconnected vcenter " | out-file -filepath $Logfile -Append
   Write-Host "Current connections:"
    $Global:DefaultVIServers.count

  }

catch
      {

     Write-Host -foregroundColor Red -backgroundColor Black "`nCould not authenticate to vCenter"
     Write-Output " notdisconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit

      }
}


function CreateSnapshots()

{

BEGIN
{
Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope Session  -Confirm:$false
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED"
}

PROCESS
{
$tz= "UTC"

$file = "c:\temp\hostname.txt"
$content = Get-Content $file
 try
 {
connectVcenters -VCname sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com,vcenter.sddc-13-52-195-209.vmwarevmc.com, vcenter.sddc-13-52-169-49.vmwarevmc.com
Write-Host "Current connections:"
    $Global:DefaultVIServers.count
foreach($name in $content)
  {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc

Start-Sleep 30
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
Write-Host "Current connections:"
    $Global:DefaultVIServers.count
   }
else
   {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
   }
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ErrorAction  SilentlyContinue
if ($ExistingSnapshot -AND $Exists)
   {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd - SNAPSHOT-COMPLETED" | out-file -filepath $Logfile -Append
   }
else 
   {
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
   }
 }
disconnectVcenters
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append

 }

catch
    {

 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
     }

  }
END
	{
	   #No action required
	}

}

#connectVcenters -VCname sv2wnvcsrv01.global.equinix.com,ch3wnvcsrv04.global.equinix.com
#disconnectVcenters

CreateSnapshots
Write-Host "Current connections:"
$Global:DefaultVIServers.count
