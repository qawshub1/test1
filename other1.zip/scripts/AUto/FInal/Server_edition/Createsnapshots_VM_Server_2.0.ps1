﻿$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
$vccred | Export-Clixml E:\scripts\VCCred.xml

$global:test1 = $true

Try

{

$Logfile = "E:\logs\snapshotCreationlog.txt"
$file = "E:\VMfolder\hostname.txt"
$content = Get-Content $file
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$VCcred = Import-Clixml E:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
 {
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc

Start-Sleep 30
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
 }
else
  {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
  }

if ($ExistingSnapshot -AND $Exists)
 {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd - SNAPSHOT-COMPLETED" | out-file -filepath $Logfile -Append
 }
else 
 {
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
 }
}
 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}

catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }
