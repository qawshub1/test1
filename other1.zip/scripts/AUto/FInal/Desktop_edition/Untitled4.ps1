﻿$timeout = New-TimeSpan -Seconds 5
$endTime = (Get-Date).Add($timeout)
do {
    $result = get-something
}
until ($result -eq "Success" -or ((Get-Date) -gt $endTime))