﻿
Start-ThreadJob -ScriptBlock
{
Try

{

$Logfile = "c:\logs\snapshotCreationlog.txt"
$file = "c:\temp\hostname.txt"
$content = Get-Content $file
$Snapshotdesc ="testiung"
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
  
   

$timeout = New-TimeSpan -Seconds 120
$endTime = (Get-Date).Add($timeout)
$counter =0

 Write-Output "$vm- SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
#write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED inside do loop" | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc

do
  {
$ExistingSnapshot= get-snapshot -vm $vm 
$counter += 1
Start-Sleep 10
 Write-Host " In progress" $vm
  } until ($ExistingSnapshot -or $counter -ge 10)
 write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $vm + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -  - SNAPSHOT_STS- COMPLETED after coming out from do loop" | out-file -filepath $Logfile -Append
 Write-Host " job  completed" $vm
  } 
  write-Host " job  completed"
#Start-Sleep 30
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
  
else
  {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
  }
  
 if ($ExistingSnapshot -AND $Exists)
  {
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $vm + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED outside" | out-file -filepath $Logfile -Append
  }
else 
  {
 Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $vm + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd -SNAPSHOT_STS- FAILED outside" | out-file -filepath $Logfile -Append
  }
 }


 
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}
catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }
 }