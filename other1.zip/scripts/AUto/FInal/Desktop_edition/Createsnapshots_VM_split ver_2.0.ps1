﻿$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
$vccred | Export-Clixml C:\scripts\VCCred.xml

$global:test1 = $true

Try

{

$Logfile = "c:\logs\snapshotCreationlog.txt"
$file = "c:\temp\hostname.txt"
$content = Get-Content $file
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $Logfile -Append
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

foreach($name in $content)
 {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
 {
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc

Start-Sleep 30
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
 }
else
  {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
  }
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ErrorAction  SilentlyContinue
if ($ExistingSnapshot -AND $Exists)
 {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd - SNAPSHOT-COMPLETED" | out-file -filepath $Logfile -Append
 }
else 
 {
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $pd -SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
 }
}
 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append
Disconnect-VIServer * -Force -confirm:$false
}

catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append
  return 'Error:' + $_.Exception.Message 
 }
