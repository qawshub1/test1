﻿$Logfile = "c:\logs\snapshotCreationlog.txt"
$file = "c:\temp\test.txt"
$temp = Get-Content $file
foreach($tx in $temp)
{
$inline = $tx.split("|")
$pd = $inline.GetValue(0)
$vm= $inline.GetValue(1)
write-host  "$vm"
write-host  "$pd"
#Write-host "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss"))- $pd - $vm -SNAPSHOT_STS- STARTED"
#Write-host "'PrePATCH-'$pd'-'(Get-Date -Format "MM-dd-yyyy hh:mm:ss")
#$Snapshotdesc = 'PrePATCH- '+ $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$dt= Get-Date -format "MMddyyyyy"
#write-host PrePATCH-$pd'-'$dt
Write-Output "$pd -$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $Logfile -Append
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
Write-host $Snapshotdesc
}
