﻿$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -STARTED" | out-file -filepath $Logfile -Append

function connectVcenters()
 {
param(
 $VCname
     )

BEGIN
 {
 #$Key = New-Object Byte[] 32
  #[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
  #$Key | out-file E:\scripts\aes.key
   #(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
  
  
  # $Global:DefaultVIServers.count
   Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
   Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
   Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
   Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
   $encPw =Get-Content e:\scripts\pwds.txt |  ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
   $crede =New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User",$encPw)
 }

 process
 {

  try 
  {
  
  foreach ($vc in $VCname)
    {
   Connect-VIServer -Credential $crede -Server $Vcname -force -ErrorAction:SilentlyContinue
    Write-Output " Sconnected vcenter " | out-file -filepath $Logfile -Append
    }
  }

catch
    {

     Write-Output "not connected to vcenter" | out-file -filepath $Logfile -Append
     exit

     }
      
   }
 END
  {
	   #No action required
  }
  }
function disconnectVcenters()
{

 try 
  {
  
   Disconnect-VIServer * -Force -confirm:$false
 
  # Write-Output " disconnected to vcenter " | out-file -filepath $Logfile -Append
  
   }

catch
    {
    
     Write-Output " notdisconnectedconnected vcenter " | out-file -filepath $Logfile -Append
     exit
    }
}


function CreateSnapshots()

{

BEGIN
 {
#$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - SCRIPT -STARTED"

 }

PROCESS
 {
$tz= "UTC"
$file = "E:\VMfolder\hostname.txt"
$content = Get-Content $file
 
 try
   {
connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
connectVcenters -VCname ch3wnvcsrv04.global.equinix.com
#connectVcenters -VCname vcenter.sddc-13-52-195-209.vmwarevmc.com
#connectVcenters -VCname vcenter.sddc-13-52-169-49.vmwarevmc.com

#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) + 'Current connections after connecting to vcenter inside process:'" $Global:DefaultVIServers.count  | out-file -filepath $Logfile -Append
foreach($name in $content)
    {
 $inline = $name.split("|")
 $pd =$inline.GetValue(0)
 $vm =$inline.GetValue(1)
 $dt= Get-Date -format "MMddyyyyy"
#$Snapshotdesc = 'PrePATCH-'+$pd+'-'+$dt
$Snapshotdesc = $pd+'_'+$vm+'_Pace'
#$Snapshotdesc = 'PrePATCH- '+ $pd + '-' + $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED" | out-file -filepath $Logfile -Append
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
  {
$counter =0

Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc -RunAsync
do
   {

$ExistingSnapshot = get-snapshot -vm $vm 
$counter += 1
Start-Sleep 10
   } until ($ExistingSnapshot -or $counter -ge 10)


#Write-Host "Current connections after creating snapshots $vm :"
#    $Global:DefaultVIServers.count
  }
else
   {
Write-Output "$vm - NOT FOUND" | out-file -filepath $Logfile -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $Logfile -Append
   }

if ($ExistingSnapshot -AND $Exists)
   {
write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- COMPLETED" | out-file -filepath $Logfile -Append

   }
else 
   {
   Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- FAILED" | out-file -filepath $Logfile -Append
    }
 }
disconnectVcenters
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" | out-file -filepath $Logfile -Append


 }

catch
    {
Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED" | out-file -filepath $Logfile -Append

  return 'Error:' + $_.Exception.Message 
     }

  }
END
	{
	   #No action required
	}

}

 function Get-Dsspace()
  
  
  {
    [CmdletBinding()]
	[OutputType([boolean])]
    
  param 
  (
    $vmname
  )
  BEGIN
  {
  #connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
 
  
  }

  PROCESS
  {
  ForEach ($vm in $vmname ) 
  
   {
 
$thresholds = "{0:n2}" -f 10
$dsfreespace = get-datastore -VM $vm | select-object @{N="DSFreespace"; E={[math]::Round(($_.FreeSpaceGB)/($_.CapacityGB)*100,2)}} | Select-Object -ExpandProperty DSFreespace
Write-Host "datastore free space $vm $dsfreespace "
Write-Host "datastore thresholds  $tresholds"
if (($dsfreespace -gt $thresholds)) 
      {
Write-Host "can take a snapshot. Datastore free space is higher than 10% $vm"
return $true

      }
 else
      {
Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
return $false
      }
   }
  }
  END
  {

  }
}

CreateSnapshots
#Write-Host "Current connections after creating snapshots:"
#$Global:DefaultVIServers.count
