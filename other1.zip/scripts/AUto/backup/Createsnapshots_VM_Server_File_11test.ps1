﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 1:13 AM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -STARTED" | out-file -filepath $Logfile -Append

function Connect-Vcenter()
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param (
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC
		
	)
	
	BEGIN
	{
		#$Key = New-Object Byte[] 32
		#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
		#$Key | out-file E:\scripts\aes.key
		#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
		
		
		# $Global:DefaultVIServers.count
		Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
		Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
		Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
		Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
		$encPw = Get-Content e:\scripts\pwds.txt | ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
		$crede = New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User", $encPw)
	}
	
	PROCESS
	{
		
		if (Connect-VIServer -Credential $crede -Server $vcenterSVC -force -ErrorAction:SilentlyContinue)
		{ Return $true }
		else
		{
			Return $false
		}
		
		
	}
	END
	{
		#No action required
	}
}
function Disconnect-Vcenter()
{
	
	[CmdletBinding()]
	[OutputType([boolean])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		Disconnect-VIServer -Server $vcenterSVC -Confirm:$false | Write-Output
	}
	END
	{
		# Nothing
	}
	
}

function Write-log()
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[system.String[]]$snapout
		
	)
	
	BEGIN
	{
		$writetofile = New-Object System.Collections.ArrayList
		$writetofile.Clear()
	}
	PROCESS
	{
		
		$writetofile.Count
		Write-Output $writetofile "before adding"
		[void]$writetofile.Add($snapout)
		
		Write-Output $writetofile
		#$writetofile.Count
		
		
		
	}
	END
	{
		# Nothing
	}
}

function Get-VMAvailable()
{
	[CmdletBinding()]
	[OutputType([pscutomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		if ((Get-VM -name $vminfo.vm -ea SilentlyContinue) -ne $null) { return $vminfo }
		else
		{
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) + '-' + $vminfo.vm + 'Not Found'"
			Exit
		}
	}
	END
	{
		# Nothing
	}
}

function Add-Snapshot()
{
	[CmdletBinding()]
	[OutputType([pscutomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	BEGIN
	{
		# Do nothing
	}
	
	PROCESS
	{
		#$file = "E:\VMfolder\hostname.txt"
		#$content = Get-Content $file
		#[String]$vmname
		
		try
		{
			$Snapshotdesc = $vminfo.pd + '_' + $vminfo.vm + '_Pace'
			Get-VM $vminfo.vm | New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - SNAPSHOT_STS- STARTED"
			Return $vminfo
		}
		
		catch
		{
			Write-log "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT FAILED"
			return 'Error:' + $_.Exception.Message
		}
	}
	END
	{
		#No action required
	}
	
}

function Get-Dsspace()
{
	[CmdletBinding()]
	[OutputType([pscutomobject])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	BEGIN
	{
		#connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
	}
	
	PROCESS
	{
		$thresholds = "{ 0:n2 }" -f 10
		$dsfreespace = get-datastore -VM $vminfo.vm | select-object @{ N = "DSFreespace"; E = { [math]::Round(($_.FreeSpaceGB)/($_.CapacityGB) * 100, 2) } } | Select-Object -ExpandProperty DSFreespace
		#			Write-Host "datastore free space $vm $dsfreespace "
		#			Write-Host "datastore thresholds  $tresholds"
		if (($dsfreespace -gt $thresholds))
		{
			##				Write-Host "can take a snapshot. Datastore free space is higher than 10% $vm"
			return $vminfo
		}
		else #				Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
		{
			#			Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
			$vminfo.message = "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss")) + ' UTC ' + $((Get-Date).ToUniversalTime().ToString("yyyy")) + '-' + $vminfo.vm + 'Datastore free space Not available'"
			Exit
		}
	}
	END
	{
		
	}
}

function Get-SnapShotVM
{
	[CmdletBinding()]
	[OutputType([bool])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		$ExistingSnapshot = Get-VM -name $vminfo.vm | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue
		if ($ExistingSnapshot)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_STS- COMPLETED"
			Return $vmInfo
		}
		else
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_STS- NOT COMPLETED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Remove-SnapShotVM
{
	[CmdletBinding()]
	[OutputType([bool])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		$ExistingSnapshot = Get-VM -name $vminfo.vm | Get-snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') | Remove-Snapshot -Confirm:$False -ea SilentlyContinue
		if ($ExistingSnapshot)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_REMOVE- COMPLETED"
			Return $vmInfo
		}
		else
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_REMOVE- NOT COMPLETED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function New-SnapShotVM
{
	[CmdletBinding()]
	[OutputType([bool])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[pscutomobject]$vminfo
	)
	
	begin
	{
		#Do Nothing
	}
	process
	{
		$ExistingSnapshot = Get-VM -name $vminfo.vm | New-Snapshot -name ($vminfo.pd + '_' + $vminfo.vm + '_Pace') -ea SilentlyContinue
		if ($ExistingSnapshot)
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_CREATE- COMPLETED"
			Return $vmInfo
		}
		else
		{
			$vmInfo.message = "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' UTC ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_CREATE- NOT COMPLETED"
			Return $vmInfo
		}
	}
	end
	{
		#Do Nothing
	}
}

function Get-AllVMSnapshot
{
	[CmdletBinding()]
	[Parameter(Mandatory = $true,
			   ValueFromPipeline = $true,
			   Position = 0)]
	[pscutomobject]$vmInfoNew
	
	begin
	{
		# Do nothing
	}
	process
	{
		$ErrorMessage = ""
		$vminfo = [pscustomobject]@{
			vcenter = $vmInfoNew.vcenters
			vm	    = $vmInfoNew.vm
			pd	    = $vmInfoNew.pd
			message = $ErrorMessage
		}
		
		$vcConnect = Connect-Vcenter -vcenterSVC $vminfo.vcenter -ea SilentlyContinue
		if ($vcconnect)
		{
			#Check VM availabel | Checkdisk for Snapshot  | takesnapshot
			$output = $vmInfo | Get-VMAvailable | Get-Dsspace | Add-Snapshot | Get-SnapShotVM
			Disconnect-Vcenter -vcenterSVC $vminfo.vcenter
		}
		else
		{
			Write-Output = "$((Get-Da).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $vminfo.venter + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - NOT CONNECTED"
			Disconnect-Vcenter -vcenterSVC $vminfo.vcenter
		}
	}
	end
	{
		#Do Nothing
	}
}



