﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 5:28 PM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$vm,
	[Parameter(Mandatory, Position = 2)]
	[string]$pkid
	
)

#Import-Module -Name ThreadJob -RequiredVersion 2.0.3 -Scope Local
#$file = "E:\VMfolder\hostname.txt"
$content = Get-Content $file
$vcentername = "sv2wnvcsrv01.global.equinix.com"
[string[]]$vcenters = $vcenter.Split(',');
[string]$VM = "test8"
[string]$id= "123"

for ($index = 0; $index -lt $vcenters.count; $index++)
{
	$threadInfo = [pscustomobject]@{
		vcenter = [string]$vcenters[$index]
		vm	    = $VM
		pd    = $id
	}
}

$holdJob = Start-ThreadJob -InitializationScript { Import-Module -Name 'E:\temp\CreateSnapshots_VM.psm1' -Scope Local; Import-Module -Name VMware.VimAutomation.Core -Scope Local } -ScriptBlock {
Add-Snapshots $using:threadInfo}

$outPut = Get-Job | Wait-Job | Receive-Job | ConvertTo-Json
return $outPut
