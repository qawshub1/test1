﻿#$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
#$vccred | Export-Clixml C:\scripts\VCCred.xml
Try
{
$file = "c:\temp\snapshotCreationlog.txt"
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $file -Append
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sg1wnvcsrv03.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname
$snapshotVM = gci C:\testfolder | %{$_.BaseName} | sort lastwritetime
$filename = (gci C:\testfolder | sort lastwritetime).name
$Snapshotdesc = 'PrePATCH'+ $snapshotVM +' '+ (Get-Date -Format "MM-dd-yyyy hh:MM:ss")
foreach($vm in $snapshotVM)
{
$Snapshotdesc = 'PrePATCH- '+ $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
Write-Output "$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $file -Append
write-host "SNAPSHOT_STS- STARTED $vm"  
Start-Sleep 30
#Get-VM $vm | get-snapshot | format-list vm,name,sizeMB,Created | out-file -filepath $file -Append
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ea SilentlyContinue
if ($ExistingSnapshot)
{
Get-VM $vm | get-snapshot | format-list vm,name,sizeMB,Created | out-file -filepath $file -Append
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:MM:ss")) - $vm - SNAPSHOT-COMPLETED" | out-file -filepath $file -Append
}
else 
{
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:MM:ss")) - $vm -SNAPSHOT_STS- FAILED" | out-file -filepath $file -Append
}

}
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:MM:ss")) -SCRIPT -COMPLETED" | out-file -filepath $file -Append
}
catch
 {
  return 'Error:' + $_.Exception.Message  
 }
 
 





