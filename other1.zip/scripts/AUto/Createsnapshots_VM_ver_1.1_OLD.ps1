﻿#$VCcred = Get-Credential -Message "Enter a service account username and password to connect ot vcenter with appropriate crednetials"
#$vccred | Export-Clixml C:\scripts\VCCred.xml
$global:test1 = $true

Try

{

$file = "c:\logs\snapshotCreationlog.txt"
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - SCRIPT -STARTED" | out-file -filepath $file -Append
$VCcred = Import-Clixml c:\scripts\VCCred.xml
$Vcname = "sv2wnvcsrv01.global.equinix.com"
Connect-VIServer -Credential $VCcred -Server $Vcname

$snapshotVM = gci C:\VMfolder | %{$_.BaseName} | sort lastwritetime

foreach($vm in $snapshotVM)
 {
$Snapshotdesc = 'PrePATCH- '+ $vm +'-'+ (Get-Date -Format "MM-dd-yyyy hh:mm:ss")
$Exists = Get-VM -name $vm -ea SilentlyContinue
if ($Exists)
 {
Get-VM $vm |  New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
Write-Output "$vm - SNAPSHOT_STS- STARTED " | out-file -filepath $file -Append
Start-Sleep 30
$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc 
 }
else
  {
Write-Output "$vm - NOT FOUND" | out-file -filepath $file -Append
Write-Output "$vm - SNAPSHOT NOT CREATED" | out-file -filepath $file -Append
  }
#$ExistingSnapshot= get-snapshot -vm $vm -Name $Snapshotdesc -ErrorAction  SilentlyContinue
if ($ExistingSnapshot -AND $Exists)
 {
write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm - SNAPSHOT-COMPLETED" | out-file -filepath $file -Append
 }
else 
 {
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) - $vm -SNAPSHOT_STS- FAILED" | out-file -filepath $file -Append
 }
}
 
Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT -COMPLETED" | out-file -filepath $file -Append
Disconnect-VIServer * -Force
}

catch
 {
$global:test1 = $false
 Write-Output "$((Get-Date).ToString("MM-dd-yyyy hh:mm:ss")) -SCRIPT  FAILED" | out-file -filepath $file -Append
  return 'Error:' + $_.Exception.Message 
 }







