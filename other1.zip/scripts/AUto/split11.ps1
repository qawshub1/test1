﻿$file = "c:\temp\test.txt"
$temp = Get-Content $file
foreach($tx in $temp)
{
$nline = $tx.split("|")
$pd = $nline.GetValue(0)
$vm= $nline.GetValue(1)
write-host  "$vm"
write-host  "$pd"
#Write-host "-$pid -$vm - SNAPSHOT_STS- STARTED "


}
