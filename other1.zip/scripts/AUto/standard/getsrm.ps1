﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 1:25 AM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Requires -Version 7.0

#Version 2.0 - Sean Li seli@equinix.com

[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$vm,
	[Parameter(Mandatory, Position = 2)]
	[string]$user,
	[Parameter(Mandatory, Position = 3)]
	[string]$password
)

Import-Module -Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\VMThread.psm1' -Scope Local
Import-Module -Name VMware.VimAutomation.Core -Scope Local

function Get-SRMList
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vm
	)
	
	BEGIN
	{
		#DONE: 
	}
	PROCESS
	{
		
	}
	END
	{
		#DONE: 
	}
}

if (Connect-SessionVC -vcenterSVC $vcenter -userSVC $user -passwordSVC $password)
{
	Get-SRMList -vm $vm
	
}





