﻿$pd = "test"
$tz="UTC"
$dt= Get-Date -format "MMddyyyyy"
[string] $logs = $dt
[string[]]$writelogs =  "temp"
#$writetemps.GetType()
#$writetemps.count
$writelogs.add("$dt")
$writetemps.count


#$writelogs.add("test")
#$writetofile.add("$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) - $pd - SNAPSHOT_STS- STARTED")
#write-output $writelogs
#$writelogs.clear()
write-output $writelogs

#Write-Output $((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' '+ $tz + ' '+ (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED 