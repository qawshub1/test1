﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 1:13 AM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#$Logfile = "E:\logs\ospatchSnapshotCreation_$(Get-Date -Format yyyyMMdd_HHmmss).log"
#Write-Output "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -STARTED" | out-file -filepath $Logfile -Append

function Connect-Vcenters()
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param (
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC

	   	)
	
	BEGIN
	{
		#$Key = New-Object Byte[] 32
		#[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
		#$Key | out-file E:\scripts\aes.key
		#(get-credential).Password | ConvertFrom-SecureString -key (get-content E:\scripts\aes.key) | set-content "E:\scripts\pwds.txt"
		
		
		# $Global:DefaultVIServers.count
		Import-Module VMware.VimAutomation.Core -WarningAction SilentlyContinue
		Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false
		Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCEIP $false -Confirm:$false
		Set-PowerCLIConfiguration -DefaultVIServerMode multiple -scope User -Confirm:$false
		$encPw = Get-Content e:\scripts\pwds.txt | ConvertTo-SecureString -key (Get-Content e:\scripts\aes.key)
		$crede = New-Object System.Management.Automation.PsCredential("Global\AMP-Admin-User", $encPw)
	}
	
	PROCESS
	{
			
				if (Connect-VIServer -Credential $crede -Server $vcenterSVC -force -ErrorAction:SilentlyContinue)
				{ Return $true }
				else
				{
					Return $false
				}
		
			
	}
	END
	{
		#No action required
	}
}
function Disconnect-Vcenters()
{
	
	[CmdletBinding()]
	[OutputType([boolean])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vcenterSVC
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		Disconnect-VIServer -Server $vcenterSVC -Confirm:$false | Write-Output
	}
	END
	{
		# Nothing
	}

}

function Write-logs()
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[system.String[]]$snapout
		
	)
	
	BEGIN
	{
		$writetofile = New-Object System.Collections.ArrayList
		$writetofile.Clear()
	}
	PROCESS
	{
		
		$writetofile.Count
		Write-Output $writetofile "before adding"
		[void]$writetofile.Add($snapout)
		
		Write-Output $writetofile
		#$writetofile.Count
		
		
		
	}
	END
	{
		# Nothing
	}
}

function Get-VMList()
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[string]$vm
	)
	
	BEGIN
	{
		# Nothing
	}
	PROCESS
	{
		$vmList = Get-VM -name $vm -ea SilentlyContinue
		if ($vmlist)
		{ 
		return $vmList
		}
		else
		{
			Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $vm + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - NOT FOUND"
		}
		
	}
	END
	{
		# Nothing
	}
}

function Add-Snapshots()
{
		[CmdletBinding()]
		[OutputType([string])]
		param
		(
			[Parameter(Mandatory = $true,
					   ValueFromPipeline = $true,
					   Position = 0)]
		[pscutomobject[]]$vminfo
	
		)
	BEGIN
	{

		
	}
	
	PROCESS
	{
		$tz = "UTC"
		#$file = "E:\VMfolder\hostname.txt"
		#$content = Get-Content $file
		[String] $vmname
		
		try
		{
			$vcConnect = Connect-Vcenters -vcenterSVC $vminfo.vcenter
			if ($vcconnect)
			{
				#$dt = Get-Date -format "MMddyyyyy"
				$Snapshotdesc = $vminfo.pd + '_' + $vminfo.vm + '_Pace'
				Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - connected vcenter"
				Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - SNAPSHOT_STS- STARTED"
				$vmname = ($vminfo.vm) | Get-VMList
				Get-VM $vmname | New-Snapshot -Name $Snapshotdesc -Description $Snapshotdesc
				
			}
			
			else
			{
				Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $vminfo.venter + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - NOT CONNECTED"
				
				Disconnect-Vcenters -vcenterSVC $vminfo.vcenter
			}
		
		   #$inline = $name.split("|")
			#$pd = $inline.GetValue(0)
			#$vm = $inline.GetValue(1)
			
			$counter = 0
			
			$ExistingSnapshot = get-snapshot -vm $vm
		<# do
					{
						
						$ExistingSnapshot = get-snapshot -vm $vm
						$counter += 1
						Start-Sleep 10
					}
					until ($ExistingSnapshot -or $counter -ge 10)
					
					
					#Write-Host "Current connections after creating snapshots $vm :"
					#  $Global:DefaultVIServers.count
				
	#>
				
				if ($ExistingSnapshot)
			    {
				Write-logs -snapout "$((Get-Date).ToUniversalTim().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_STS- COMPLETED"
					
				}
				else
			{
				Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) - $vminfo.pd - SNAPSHOT_STS- COMPLETED"
		
			}
			
			Disconnect-Vcenters -vcenterSVC $vminfo.vcenter
			Write-logs -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT -COMPLETED" 
			
			
		}
		
		catch
		{
			Write-logs "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy")) -SCRIPT  FAILED"
			
			return 'Error:' + $_.Exception.Message
		}
		
	}
	END
	{
		#No action required
	}
	
}

function Get-Dsspace()
{
	[CmdletBinding()]
	[OutputType([boolean])]
	param
	(
		$vmname
	)
	BEGIN
	{
		#connectVcenters -VCname sv2wnvcsrv01.global.equinix.com
		
		
	}
	
	PROCESS
	{
		ForEach ($vm in $vmname)
		{
			
			$thresholds = "{0:n2}" -f 10
			$dsfreespace = get-datastore -VM $vm | select-object @{ N = "DSFreespace"; E = { [math]::Round(($_.FreeSpaceGB)/($_.CapacityGB) * 100, 2) } } | Select-Object -ExpandProperty DSFreespace
			Write-Host "datastore free space $vm $dsfreespace "
			Write-Host "datastore thresholds  $tresholds"
			if (($dsfreespace -gt $thresholds))
			{
				Write-Host "can take a snapshot. Datastore free space is higher than 10% $vm"
				return $true
				
			}
			else
			{
				Write-Host " cannot take a snapshot. Datastore free space is lower than 10% $vm"
				return $false
			}
		}
	}
	END
	{
		
	}
}


#Write-Host "Current connections after creating snapshots:"
#$Global:DefaultVIServers.count



