﻿#Version 2.0 - Sean Li seli@equinix.com

[OutputType([string])]
Param (
	[Parameter(Mandatory, Position = 0)]
	[string]$vcenter,
	[Parameter(Mandatory, Position = 1)]
	[string]$vm,
    [Parameter(Mandatory, Position = 2)]
	[string]$pkid,
	[Parameter(Mandatory, Position = 3)]
	[string]$user,
	[Parameter(Mandatory, Position = 4)]
	[string]$password
)

Import-Module -Name ThreadJob -RequiredVersion 2.0.3 -Scope Local
#Import-Module --Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\CreateSano.psm1' -Scope Local #for debug

[string[]]$vcenterApi = $vcenter.Split(',');

for ($index = 0; $index -lt $vcenterApi.count; $index++)
{
	$threadInfo = [pscustomobject]@{
		vcenter = [string]$vcenterApi[$index]
		vm   = [string]$vm #VM1,vm2,vm3,mv4
        pkid    = [string]$pkid #ID1,ID2,ID3
		user    = [string]$user
		password = [string]$password
	}

     $threadInfo | Get-writeSnap |write-output 
	#$holdJob = Start-ThreadJob -InitializationScript { Import-Module -Name 'C:\Users\seli\Documents\SAPIEN\PowerShell Studio\Files\CreateSano.psm1' -Scope Local; Import-Module -Name VMware.VimAutomation.Core -Scope Local } -ScriptBlock { Get
WriteSnap $using:threadInfo }
}

$outPut = Get-Job | Wait-Job | Receive-Job | ConvertTo-Json
return $outPut


#Get-VMsnapshotstatus -vcenter 'vc1' -vm 'VM1,VM2,VM3' -pkid 'id1,id2,id3' -user test@equinix -password 'badpassword'
 # Tue Jul 13 18:59:31 UTC 2021 - 2071 - SNAPSHOT_STS- COMPLETED