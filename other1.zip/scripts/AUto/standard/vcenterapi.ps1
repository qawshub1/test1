﻿$vcenter = "test1.svc"

[string[]]$test = $vcenter.Split(',');
Write-Output $test
