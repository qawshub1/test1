﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/18/2021 12:25 AM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.191
	 Created on:   	7/17/2021 11:59 PM
	 Created by:   	ramsubramanian
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>function Writetofile()
{
	[CmdletBinding()]
	[OutputType([string])]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 0)]
		[system.String[]]$snapout
		
	)
	
	BEGIN
	{
		$writetofile = New-Object System.Collections.ArrayList
		$writetofile.Clear()
	}
	PROCESS
	{
		
		$writetofile.Count
		Write-Output $writetofile "before adding"
		[void]$writetofile.Add($snapout)
	
		Write-Output $writetofile
		#$writetofile.Count
		
		
		
	}
	END
	{
		# Nothing
	}
	
}


$tz= "UTC"

Writetofile -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - SNAPSHOT_STS- STARTED"
Writetofile -snapout "$((Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss") + ' ' + $tz + ' ' + (Get-Date).ToUniversalTime().ToString("yyyy"))  - SNAPSHOT_STS- STARTED2"


