﻿$vmInfo = [pscustomobject]@{
	vcenter = [string]'sv2wnvcsrv01.global.equinix.com'
	vm	    = [string]'Test8'
	pd	    = [string]'214'
	message = ""
}
Import-Module .\VMsnapshots.psm1
$vcConnect = Connect-VIServer -Server sv2wnvcsrv01.global.equinix.com
